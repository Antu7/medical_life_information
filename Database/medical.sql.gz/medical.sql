-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `diseases`;
CREATE TABLE `diseases` (
  `diseases_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `diseases_name` varchar(255) NOT NULL,
  `diseases_status` varchar(255) NOT NULL,
  `doctor_info` varchar(255) NOT NULL,
  `patient_prescription` varchar(255) NOT NULL,
  `patient_report` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  PRIMARY KEY (`diseases_id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `diseases_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `diseases` (`diseases_id`, `patient_id`, `diseases_name`, `diseases_status`, `doctor_info`, `patient_prescription`, `patient_report`, `date`) VALUES
(4,	1,	'Appendicite',	'0',	'Professor Dr. ( Brig. Gen ) Md. Saidur Rahman , MBBS, FCPS ( Surgery ) , Professor & Head, Department of Surgery, General Surgeon ',	'image/patient_prescription_picture/1.JPG',	'image/patient_prescription_picture/medical_reporting_allergies.png',	'2011-07-9'),
(5,	1,	'Heart disease',	'1',	'Dr. A F M Anowar Hossain , MBBS, FCPS, MS, Assistant Professor, Surgical Oncology , National Cancer Institute & Hospital, Dhaka',	'image/patient_prescription_picture/Prescription_Dr_IC_Verma_Gangarams_Delhi_1474278640.jpg',	'image/patient_prescription_picture/report.jpeg',	'2014-05-03'),
(6,	1,	'Diabetes',	'1',	'Dr. A K M Hamidur Rahman , MBBS, DMRT, Associate Professor, Cancer - Oncology',	'image/patient_prescription_picture/prescription.jpg',	'image/patient_prescription_picture/MEDICAL-REPORT.png',	'2015-07-03'),
(7,	1,	'Malaria',	'0',	'Professor Dr. A.F. Masood, MBBS, FRCS ( Eng. ), FICS, Professor, Orthopaedic Surgeon, Bangladesh Institue of Child Health, Dhaka Shishu Hospital ( From Rtd. )',	'image/patient_prescription_picture/bhargav-dr-prescription-20100218-1-728.jpg',	'image/patient_prescription_picture/report1.jpeg',	'2016-02-15'),
(8,	1,	'Tonsillitis',	'0',	'Professor Dr. Abu Zafar , MBBS, MRCP ( UK ), FRCP ( Glasgow ), Professor, Ex - Head, Dept. of Cardiology , BSMMU',	'image/patient_prescription_picture/Prescription_Dr_IC_Verma_Gangarams_Delhi_14742786401.jpg',	'image/patient_prescription_picture/report2.jpeg',	'2016-08-15'),
(9,	1,	'Paratyphoid fever',	'1',	'Professor Dr. ( Brig. Gen ) Md. Saidur Rahman , MBBS, FCPS ( Surgery ) , Professor & Head, Department of Surgery, General Surgeon , Armed Forces Medical College, Dhaka',	'image/patient_prescription_picture/bhargav-dr-prescription-20100218-1-7281.jpg',	'image/patient_prescription_picture/prescription1.jpg',	'2017-01-12'),
(10,	1,	'Typhoid fever',	'0',	'Dr. A F M Anowar Hossain, MBBS, FCPS, MS, Assistant Professor, Surgical Oncology , National Cancer Institute & Hospital, Dhaka',	'image/patient_prescription_picture/bhargav-dr-prescription-20100218-1-7282.jpg',	'image/patient_prescription_picture/MEDICAL-REPORT1.png',	'2017-02-12');

DROP TABLE IF EXISTS `doctor`;
CREATE TABLE `doctor` (
  `doctor_id` int(11) NOT NULL AUTO_INCREMENT,
  `doctor_name` varchar(255) NOT NULL,
  `doctor_image` varchar(255) NOT NULL,
  `doctor_email` varchar(255) NOT NULL,
  `doctor_password` varchar(255) NOT NULL,
  `doctor_phone` varchar(255) NOT NULL,
  `doctor_gender` varchar(255) NOT NULL,
  `doctor_nid` varchar(255) NOT NULL,
  `doctor_birthday` varchar(255) NOT NULL,
  `professional_information` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  PRIMARY KEY (`doctor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `doctor` (`doctor_id`, `doctor_name`, `doctor_image`, `doctor_email`, `doctor_password`, `doctor_phone`, `doctor_gender`, `doctor_nid`, `doctor_birthday`, `professional_information`, `designation`) VALUES
(1,	'Tanvir',	'image/doctor_profile_picture/doctor-smiling-with-stethoscope_1154-362.jpg',	'tanvir@gmail.com',	'antu',	'23423423',	'Male',	'34234324',	'9-2-1222',	'MBBS, MS (Surgery)',	'Professor Of Neurosurgery ');

DROP TABLE IF EXISTS `patient`;
CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_name` varchar(255) NOT NULL,
  `patient_email` varchar(255) NOT NULL,
  `patient_phone` varchar(255) NOT NULL,
  `patient_password` varchar(255) NOT NULL,
  `patient_blood_group` varchar(255) NOT NULL,
  `patient_nid` varchar(255) NOT NULL,
  `patient_gender` varchar(255) NOT NULL,
  `patient_birthday` varchar(255) NOT NULL,
  `patient_image` varchar(255) NOT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `patient` (`patient_id`, `patient_name`, `patient_email`, `patient_phone`, `patient_password`, `patient_blood_group`, `patient_nid`, `patient_gender`, `patient_birthday`, `patient_image`) VALUES
(1,	'Mr Antu',	'antu@gmail.com',	'01571713338',	'antu',	'B+',	'079807698587465354',	'Male',	'3-3-1992',	'image/patient_profile_picture/594ced2fe8e661.jpg'),
(2,	'Mr Nobody',	'nobody@gmail.com',	'234234234',	'antu',	'O+',	'3423423',	'Female',	'0003-03-03',	'image/patient_profile_picture/375867-mashrafe-mortaza-odi-clbb-7.jpg');

-- 2017-10-30 16:50:31
